require('option')               -- 默认选项
require('keymap')               -- 按键绑定
